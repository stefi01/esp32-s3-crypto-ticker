/*
  Coin desk — Freenove FNK0115B, 4.3 inch TN, 480x272.
  Face is a giant clock, a weather widget, one coin, and its graph.
  One MENU button. Wi-Fi, dim, light, and coins live in the menu.
  Prices and the graph come from Kraken's public feed. No account.
  XPT2046_Touchscreen.h and .cpp sit in this folder. Touch SPI is 1 MHz.
  The panel bounce buffer is 272 * 20 so the picture does not slide.
  Own prefs name cdesk. Does not clear weather, trains, the scope, or ships.
  Menu: ESP32S3 Dev Module, OPI PSRAM, Flash 16MB, USB CDC On Boot Enabled.
*/

#include <Arduino_GFX_Library.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <SPI.h>
#include "XPT2046_Touchscreen.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define GFX_BL 2
#define PW 480
#define PH 272
#define PIN_DE 40
#define PIN_VSYNC 41
#define PIN_HSYNC 39
#define PIN_PCLK 42
#define TOUCH_SCK 12
#define TOUCH_MISO 13
#define TOUCH_MOSI 11
#define TOUCH_CS 38
#define TOUCH_IRQ 18
#define KW 48
#define MAX_G 60

enum { PG_FACE = 0, PG_MENU, PG_COINS, PG_WIFI };

XPT2046_Touchscreen ts(TOUCH_CS, TOUCH_IRQ);
Arduino_ESP32RGBPanel *rgbBus = nullptr;
Arduino_RGB_Display *panel = nullptr;
Arduino_GFX *gfx = nullptr;
Preferences prefs;
portMUX_TYPE coinMux = portMUX_INITIALIZER_UNLOCKED;

uint16_t COL_BG, COL_TXT, COL_HOT, COL_DIM, COL_MID, COL_UP, COL_DN, COL_WHT;

struct CoinDef {
  const char *name;
  const char *pair;
};

static const CoinDef COINS[] = {
    {"BTC", "XBTUSD"}, {"ETH", "ETHUSD"}, {"SOL", "SOLUSD"}, {"XRP", "XRPUSD"},
    {"DOGE", "XDGUSD"}, {"ADA", "ADAUSD"}, {"AVAX", "AVAXUSD"}, {"LINK", "LINKUSD"},
    {"LTC", "LTCUSD"}, {"DOT", "DOTUSD"}, {"TRX", "TRXUSD"}, {"TON", "TONUSD"},
    {"UNI", "UNIUSD"}, {"NEAR", "NEARUSD"}, {"ATOM", "ATOMUSD"}, {"PEPE", "PEPEUSD"},
};
const int NCOIN = (int)(sizeof(COINS) / sizeof(COINS[0]));

static const int HOLD_SEC[] = {15, 30, 60, 300};
static const char *HOLD_NAME[] = {"15s", "30s", "1m", "5m"};
const int NHOLD = 4;

static const int RANGE_MIN[] = {1, 5, 30, 240};
static const int RANGE_SPAN[] = {3600, 4 * 3600, 86400, 7 * 86400};
static const char *RANGE_NAME[] = {"1H", "4H", "24H", "1W"};
const int NRANGE = 4;

static const char *WDAY[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
static const char *MON[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

int page = PG_FACE;
int coinIx = 0;
int rangeIx = 2;
int holdIx = 1;
int lookIx = 0;
int blLevel = 2;
int useC = 0;
uint32_t coinMask = 0x3;
volatile bool netPause = false;
volatile bool faceDirty = false;
volatile bool pullNow = true;

float price = 0;
float barO[MAX_G], barH[MAX_G], barL[MAX_G], barC[MAX_G];
int nGraph = 0;
bool graphUp = true;
bool quoteOk = false;
char place[20] = "";
float wxC = 0;
int wxCode = -1;
bool wxOk = false;
bool havePlace = false;
int fngVal = -1;
char fngName[16] = "";
bool fngOk = false;
float placeLat = 0, placeLon = 0;

char wifiSsid[64] = "";
char wifiPass[64] = "";
char wifiScan[16][33];
int nWifiScan = 0, wifiScanTop = 0, wifiFocus = 0;
bool wifiShift = false, wifiSym = false, wifiScanBusy = false;
char wifiMsg[28] = "";
uint32_t lastTouch = 0;
bool fingerDown = false;

void cols() {
  COL_BG = RGB565(8, 10, 14);
  COL_TXT = RGB565(236, 238, 242);
  COL_HOT = RGB565(255, 176, 48);
  COL_DIM = RGB565(22, 26, 34);
  COL_MID = RGB565(140, 148, 160);
  COL_UP = RGB565(46, 196, 96);
  COL_DN = RGB565(226, 64, 72);
  COL_WHT = RGB565(250, 250, 252);
}

void applyBl() {
  pinMode(GFX_BL, OUTPUT);
  if (blLevel >= 2) {
    digitalWrite(GFX_BL, HIGH);
    return;
  }
  analogWrite(GFX_BL, blLevel == 0 ? 70 : 150);
}

void centre(const char *s, int cx, int y) {
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  gfx->setCursor(cx - (int)w / 2, y);
  gfx->print(s);
}

bool hit(int x, int y, int x0, int y0, int x1, int y1) {
  return x >= x0 && x <= x1 && y >= y0 && y <= y1;
}

void chip(int x, int y, int w, int h, const char *t, bool on) {
  gfx->fillRoundRect(x, y, w, h, 3, on ? COL_HOT : COL_DIM);
  gfx->setTextColor(on ? COL_BG : COL_TXT, on ? COL_HOT : COL_DIM);
  gfx->setTextSize(1);
  centre(t, x + w / 2, y + (h / 2) - 4);
}

const char *blWord() {
  if (blLevel <= 0) return "LOW";
  if (blLevel == 1) return "MID";
  return "HIGH";
}

bool coinOn(int i) {
  return i >= 0 && i < NCOIN && (coinMask & (1UL << i));
}

int nextOn(int from) {
  for (int k = 1; k <= NCOIN; k++) {
    int j = (from + k) % NCOIN;
    if (coinOn(j)) return j;
  }
  return 0;
}

void fmtPx(char *b, int n, float v) {
  if (v >= 1000.f) snprintf(b, n, "$%.0f", v);
  else if (v >= 1.f) snprintf(b, n, "$%.2f", v);
  else if (v >= 0.01f) snprintf(b, n, "$%.4f", v);
  else snprintf(b, n, "$%.6f", v);
}

const char *skyWord(int c) {
  if (c < 0) return "";
  if (c == 0) return "clear";
  if (c <= 3) return "cloud";
  if (c == 45 || c == 48) return "fog";
  if (c >= 51 && c <= 67) return "rain";
  if (c >= 71 && c <= 77) return "snow";
  if (c >= 80 && c <= 82) return "showers";
  if (c >= 95) return "storm";
  return "sky";
}

const char *jFind(const char *json, const char *key) {
  char pat[40];
  snprintf(pat, sizeof(pat), "\"%s\":", key);
  const char *p = strstr(json, pat);
  if (!p) return nullptr;
  p += strlen(pat);
  while (*p == ' ') p++;
  return p;
}

bool jNum(const char *json, const char *key, float *out) {
  char pat[40];
  snprintf(pat, sizeof(pat), "\"%s\":", key);
  const char *p = json;
  while ((p = strstr(p, pat)) != nullptr) {
    const char *v = p + strlen(pat);
    while (*v == ' ') v++;
    if (*v != '"') {
      char *end = nullptr;
      float n = strtof(v, &end);
      if (end != v) {
        *out = n;
        return true;
      }
    }
    p += strlen(pat);
  }
  return false;
}

bool jStr(const char *json, const char *key, char *out, int n) {
  const char *p = jFind(json, key);
  if (!p || *p != '"') {
    out[0] = 0;
    return false;
  }
  p++;
  int i = 0;
  while (*p && *p != '"' && i < n - 1) out[i++] = *p++;
  out[i] = 0;
  return i > 0;
}

void noteHttp(HTTPClient &http) {
  http.setTimeout(12000);
  http.setConnectTimeout(8000);
  http.setReuse(false);
  http.setUserAgent("CoinDesk/1.0");
}

bool httpGet(const char *url, char *body, int cap) {
  body[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  noteHttp(http);
  bool ok = false;
  if (http.begin(cli, url)) {
    int code = http.GET();
    if (code == 200) {
      String s = http.getString();
      int n = s.length();
      if (n >= cap) n = cap - 1;
      if (n > 0) memcpy(body, s.c_str(), n);
      body[n] = 0;
      ok = n > 2;
    }
    http.end();
  }
  cli.stop();
  return ok;
}

bool quoteField(const char *body, const char *key, int which, float *out) {
  const char *p = strstr(body, key);
  if (!p) return false;
  p += strlen(key);
  for (int i = 0; i <= which; i++) {
    const char *a = strchr(p, '"');
    if (!a) return false;
    if (i == which) {
      *out = (float)atof(a + 1);
      return *out > 0.f;
    }
    const char *b = strchr(a + 1, '"');
    if (!b) return false;
    p = b + 1;
  }
  return false;
}

void useZone(const char *id, long offsetSec) {
  const char *posix = nullptr;
  if (id && strstr(id, "Los_Angeles")) posix = "PST8PDT,M3.2.0,M11.1.0";
  else if (id && strstr(id, "Denver")) posix = "MST7MDT,M3.2.0,M11.1.0";
  else if (id && strstr(id, "Phoenix")) posix = "MST7";
  else if (id && strstr(id, "Chicago")) posix = "CST6CDT,M3.2.0,M11.1.0";
  else if (id && strstr(id, "New_York")) posix = "EST5EDT,M3.2.0,M11.1.0";
  else if (id && strstr(id, "Anchorage")) posix = "AKST9AKDT,M3.2.0,M11.1.0";
  else if (id && strstr(id, "Honolulu")) posix = "HST10";
  if (posix) {
    configTzTime(posix, "pool.ntp.org", "time.nist.gov");
    return;
  }
  int west = (int)(-offsetSec / 3600);
  char z[12];
  snprintf(z, sizeof(z), "XXX%d", west);
  configTzTime(z, "pool.ntp.org", "time.nist.gov");
}

void pullPlace() {
  if (havePlace) return;
  char body[1400];
  if (!httpGet("https://ipwho.is/", body, sizeof(body))) return;
  float lat = 0, lon = 0, off = 0;
  if (!jNum(body, "latitude", &lat) || !jNum(body, "longitude", &lon)) return;
  jNum(body, "offset", &off);
  char id[40];
  jStr(body, "id", id, sizeof(id));
  char city[24];
  city[0] = 0;
  jStr(body, "city", city, sizeof(city));
  if (strlen(city) > 12) city[12] = 0;
  placeLat = lat;
  placeLon = lon;
  havePlace = true;
  strlcpy(place, city, sizeof(place));
  useZone(id, (long)off);
  pullNow = true;
}

void pullWeather() {
  if (!havePlace) return;
  char url[180];
  snprintf(url, sizeof(url),
           "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,weather_code&temperature_unit=%s",
           placeLat, placeLon, useC ? "celsius" : "fahrenheit");
  char body[900];
  if (!httpGet(url, body, sizeof(body))) return;
  float t = 0, code = 0;
  if (!jNum(body, "temperature_2m", &t)) return;
  jNum(body, "weather_code", &code);
  wxC = t;
  wxCode = (int)code;
  wxOk = true;
  if (page == PG_FACE) faceDirty = true;
}

void pullFear() {
  char body[400];
  if (!httpGet("https://api.alternative.me/fng/?limit=1", body, sizeof(body))) return;
  char val[8];
  char name[16];
  if (!jStr(body, "value", val, sizeof(val))) return;
  if (!jStr(body, "value_classification", name, sizeof(name))) return;
  int n = atoi(val);
  if (n < 0 || n > 100) return;
  fngVal = n;
  strlcpy(fngName, name, sizeof(fngName));
  fngOk = true;
  if (page == PG_FACE) faceDirty = true;
}

void takeCloses(char *win, int *fill, float *o, float *h, float *l, float *c, int *n) {
  int f = *fill;
  int i = 0;
  while (i < f) {
    if (win[i] != '[') {
      i++;
      continue;
    }
    if (i + 1 >= f) break;
    if (win[i + 1] < '0' || win[i + 1] > '9') {
      i++;
      continue;
    }
    int q = i + 1;
    float v[4];
    int got = 0;
    bool shortBuf = false;
    while (got < 4) {
      int a = -1;
      for (int k = q; k < f; k++) {
        if (win[k] == '"') {
          a = k;
          break;
        }
      }
      if (a < 0) {
        shortBuf = true;
        break;
      }
      int b = -1;
      for (int k = a + 1; k < f; k++) {
        if (win[k] == '"') {
          b = k;
          break;
        }
      }
      if (b < 0) {
        shortBuf = true;
        break;
      }
      int len = b - (a + 1);
      if (len <= 0 || len >= 20) {
        q = b + 1;
        got = -1;
        break;
      }
      char num[20];
      memcpy(num, win + a + 1, (size_t)len);
      num[len] = 0;
      v[got++] = (float)atof(num);
      q = b + 1;
    }
    if (shortBuf) break;
    if (got == 4 && v[3] > 0.f) {
      if (*n < MAX_G) {
        o[*n] = v[0];
        h[*n] = v[1];
        l[*n] = v[2];
        c[*n] = v[3];
        (*n)++;
      } else {
        memmove(o, o + 1, (MAX_G - 1) * sizeof(float));
        memmove(h, h + 1, (MAX_G - 1) * sizeof(float));
        memmove(l, l + 1, (MAX_G - 1) * sizeof(float));
        memmove(c, c + 1, (MAX_G - 1) * sizeof(float));
        o[MAX_G - 1] = v[0];
        h[MAX_G - 1] = v[1];
        l[MAX_G - 1] = v[2];
        c[MAX_G - 1] = v[3];
      }
      i = q;
    } else
      i = (q > i) ? q : i + 1;
  }
  if (i > 0 && i <= f) {
    memmove(win, win + i, (size_t)(f - i));
    *fill = f - i;
    win[*fill] = 0;
  }
}

bool pullCandles(const char *pair, int rng, float *o, float *h, float *l, float *c, int *nout) {
  *nout = 0;
  time_t now = time(nullptr);
  if (now < 1700000000L || rng < 0 || rng >= NRANGE) return false;
  char url[140];
  snprintf(url, sizeof(url), "https://api.kraken.com/0/public/OHLC?pair=%s&interval=%d&since=%ld", pair,
           RANGE_MIN[rng], (long)(now - RANGE_SPAN[rng]));
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  noteHttp(http);
  bool bad = false;
  bool opened = http.begin(cli, url);
  if (opened) {
    int code = http.GET();
    if (code == 200) {
      WiFiClient *stream = http.getStreamPtr();
      if (!stream) bad = true;
      else {
        stream->setTimeout(2000);
        char win[768];
        int fill = 0;
        bool checked = false;
        uint32_t t0 = millis();
        while (millis() - t0 < 12000 && !bad) {
          int room = (int)sizeof(win) - 1 - fill;
          if (room < 64) {
            takeCloses(win, &fill, o, h, l, c, nout);
            if (fill > 500) {
              memmove(win, win + 200, (size_t)(fill - 200));
              fill -= 200;
              win[fill] = 0;
            }
            room = (int)sizeof(win) - 1 - fill;
            if (room < 64) break;
          }
          int av = stream->available();
          if (av <= 0) {
            if (!http.connected()) break;
            vTaskDelay(pdMS_TO_TICKS(8));
            continue;
          }
          if (av > room) av = room;
          int r = stream->read((uint8_t *)win + fill, (size_t)av);
          if (r <= 0) break;
          fill += r;
          win[fill] = 0;
          if (!checked && fill > 24) {
            checked = true;
            if (strstr(win, "\"error\":[\"")) bad = true;
          }
          if (!bad) takeCloses(win, &fill, o, h, l, c, nout);
        }
        if (!bad) takeCloses(win, &fill, o, h, l, c, nout);
      }
    } else
      bad = true;
    http.end();
  }
  cli.stop();
  return opened && !bad && *nout >= 2;
}

bool pullTicker(const char *pair, float *last) {
  char url[96];
  snprintf(url, sizeof(url), "https://api.kraken.com/0/public/Ticker?pair=%s", pair);
  char body[1400];
  if (!httpGet(url, body, sizeof(body))) return false;
  if (strstr(body, "\"error\":[\"")) return false;
  return quoteField(body, "\"c\":", 0, last);
}

void pullCoin(int i, int rng) {
  if (i < 0 || i >= NCOIN) return;
  float last = 0;
  float o[MAX_G], h[MAX_G], l[MAX_G], c[MAX_G];
  int n = 0;
  bool tok = pullTicker(COINS[i].pair, &last);
  bool cok = tok && pullCandles(COINS[i].pair, rng, o, h, l, c, &n);
  if (i != coinIx || rng != rangeIx) return;
  portENTER_CRITICAL(&coinMux);
  if (tok) {
    price = last;
    quoteOk = true;
  }
  if (cok) {
    memcpy(barO, o, sizeof(float) * (size_t)n);
    memcpy(barH, h, sizeof(float) * (size_t)n);
    memcpy(barL, l, sizeof(float) * (size_t)n);
    memcpy(barC, c, sizeof(float) * (size_t)n);
    nGraph = n;
    graphUp = c[n - 1] >= c[0];
  }
  portEXIT_CRITICAL(&coinMux);
  if (page == PG_FACE) faceDirty = true;
}

void netTask(void *) {
  uint32_t shownAt = 0;
  uint32_t wxAt = 0;
  uint32_t fngAt = 0;
  for (;;) {
    if (netPause || WiFi.status() != WL_CONNECTED) {
      vTaskDelay(pdMS_TO_TICKS(300));
      continue;
    }
    if (!havePlace) pullPlace();
    if (!wxOk || (uint32_t)(millis() - wxAt) > 900000UL) {
      pullWeather();
      wxAt = millis();
    }
    if ((!fngOk && (uint32_t)(millis() - fngAt) > 20000UL) ||
        (fngOk && (uint32_t)(millis() - fngAt) > 1800000UL)) {
      pullFear();
      fngAt = millis();
    }
    int hold = HOLD_SEC[holdIx];
    if (hold < 15) hold = 15;
    bool due = pullNow || shownAt == 0 || (uint32_t)(millis() - shownAt) >= (uint32_t)hold * 1000UL;
    if (due && page == PG_FACE) {
      if (!pullNow && shownAt != 0) coinIx = nextOn(coinIx);
      if (!coinOn(coinIx)) coinIx = nextOn(-1);
      pullNow = false;
      pullCoin(coinIx, rangeIx);
      shownAt = millis();
    }
    vTaskDelay(pdMS_TO_TICKS(400));
  }
}

void paintClock() {
  gfx->fillRect(8, 12, 248, 58, COL_BG);
  time_t now = time(nullptr);
  struct tm ti;
  gfx->setTextColor(COL_WHT, COL_BG);
  if (now < 1700000000L || !localtime_r(&now, &ti)) {
    gfx->setTextSize(3);
    gfx->setCursor(12, 28);
    gfx->print("--:--");
    return;
  }
  int hr = ti.tm_hour % 12;
  if (!hr) hr = 12;
  char b[12];
  snprintf(b, sizeof(b), "%d:%02d", hr, ti.tm_min);
  gfx->setTextSize(6);
  gfx->setCursor(10, 14);
  gfx->print(b);
  gfx->setTextSize(2);
  gfx->setCursor(10 + (int)strlen(b) * 36 + 6, 36);
  gfx->print(ti.tm_hour >= 12 ? "PM" : "AM");
  gfx->setTextSize(1);
  gfx->setTextColor(COL_MID, COL_BG);
  snprintf(b, sizeof(b), "%s  %s %d", WDAY[ti.tm_wday], MON[ti.tm_mon], ti.tm_mday);
  gfx->setCursor(12, 66);
  gfx->print(b);
}

void paintWeather() {
  gfx->fillRoundRect(268, 14, 112, 58, 6, COL_DIM);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_MID, COL_DIM);
  gfx->setCursor(276, 18);
  gfx->print(place[0] ? place : "weather");
  gfx->setTextColor(COL_WHT, COL_DIM);
  gfx->setTextSize(3);
  gfx->setCursor(276, 32);
  if (wxOk) {
    char b[16];
    snprintf(b, sizeof(b), useC ? "%dC" : "%dF", (int)(wxC + (wxC >= 0 ? 0.5f : -0.5f)));
    gfx->print(b);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_MID, COL_DIM);
    gfx->setCursor(276, 58);
    gfx->print(skyWord(wxCode));
  } else {
    gfx->print("--");
  }
}

int gy(float v, float mn, float span, int y0, int h) {
  int y = y0 + h - 6 - (int)((v - mn) / span * (h - 12));
  if (y < y0 + 2) y = y0 + 2;
  if (y > y0 + h - 3) y = y0 + h - 3;
  return y;
}

void paintFear() {
  if (!fngOk) return;
  uint16_t col = COL_MID;
  if (fngVal <= 44) col = COL_DN;
  else if (fngVal >= 56) col = COL_UP;
  gfx->setTextSize(2);
  gfx->setTextColor(col, COL_BG);
  gfx->setCursor(12, 122);
  char b[28];
  snprintf(b, sizeof(b), "%s  %d", fngName, fngVal);
  gfx->print(b);
}

void paintGraph() {
  const int x0 = 8, y0 = 146, w = 464, h = 114;
  gfx->fillRect(0, 90, PW, PH - 90, COL_BG);
  float o[MAX_G], hi[MAX_G], lo[MAX_G], c[MAX_G];
  int n = 0;
  bool up = true;
  float px = 0;
  bool ok = false;
  int look = lookIx;
  portENTER_CRITICAL(&coinMux);
  n = nGraph;
  if (n > MAX_G) n = MAX_G;
  memcpy(o, barO, sizeof(float) * (size_t)n);
  memcpy(hi, barH, sizeof(float) * (size_t)n);
  memcpy(lo, barL, sizeof(float) * (size_t)n);
  memcpy(c, barC, sizeof(float) * (size_t)n);
  up = graphUp;
  px = price;
  ok = quoteOk;
  portEXIT_CRITICAL(&coinMux);

  uint16_t col = up ? COL_UP : COL_DN;
  gfx->setTextSize(3);
  gfx->setTextColor(COL_WHT, COL_BG);
  gfx->setCursor(12, 96);
  gfx->print(COINS[coinIx].name);
  char b[24];
  if (ok) fmtPx(b, sizeof(b), px);
  else strlcpy(b, WiFi.status() == WL_CONNECTED ? "..." : "join wifi", sizeof(b));
  gfx->setCursor(12 + (int)strlen(COINS[coinIx].name) * 18 + 10, 96);
  gfx->print(b);
  if (ok && n >= 2 && c[0] > 0.f) {
    float ch = (c[n - 1] - c[0]) / c[0] * 100.f;
    snprintf(b, sizeof(b), "%+.1f%%", ch);
    gfx->setTextSize(2);
    gfx->setTextColor(col, COL_BG);
    gfx->setCursor(300, 102);
    gfx->print(b);
  }
  if (n < 2) return;

  float mn = c[0], mx = c[0];
  for (int i = 0; i < n; i++) {
    float a = (look == 2) ? lo[i] : c[i];
    float z = (look == 2) ? hi[i] : c[i];
    if (a < mn) mn = a;
    if (z > mx) mx = z;
  }
  float span = mx - mn;
  if (span < mx * 0.0001f) span = mx * 0.0001f;
  if (span < 0.0000001f) span = 1.f;

  if (look == 2) {
    int slot = w / n;
    if (slot < 3) slot = 3;
    int bw = slot - 2;
    if (bw < 2) bw = 2;
    if (bw > 10) bw = 10;
    for (int i = 0; i < n; i++) {
      int x = x0 + (i * (w - slot)) / (n > 1 ? n - 1 : 1);
      int yHi = gy(hi[i], mn, span, y0, h);
      int yLo = gy(lo[i], mn, span, y0, h);
      int yO = gy(o[i], mn, span, y0, h);
      int yC = gy(c[i], mn, span, y0, h);
      uint16_t cc = c[i] >= o[i] ? COL_UP : COL_DN;
      gfx->drawFastVLine(x + bw / 2, yHi, yLo - yHi + 1, cc);
      int top = yO < yC ? yO : yC;
      int bh = abs(yC - yO);
      if (bh < 1) bh = 1;
      gfx->fillRect(x, top, bw, bh, cc);
    }
    return;
  }

  if (look == 1) {
    int base = y0 + h - 2;
    int prevX = x0;
    int prevY = gy(c[0], mn, span, y0, h);
    for (int i = 1; i < n; i++) {
      int x = x0 + (i * (w - 1)) / (n - 1);
      int y = gy(c[i], mn, span, y0, h);
      int xA = prevX < x ? prevX : x;
      int xB = prevX < x ? x : prevX;
      for (int xx = xA; xx <= xB; xx++) {
        int yy = prevY;
        if (xB != xA) yy = prevY + (y - prevY) * (xx - prevX) / (x - prevX);
        if (yy > base) yy = base;
        gfx->drawFastVLine(xx, yy, base - yy, col);
      }
      prevX = x;
      prevY = y;
    }
    return;
  }

  int py = gy(c[0], mn, span, y0, h);
  int px0 = x0;
  for (int i = 1; i < n; i++) {
    int x = x0 + (i * (w - 1)) / (n - 1);
    int y = gy(c[i], mn, span, y0, h);
    gfx->drawLine(px0, py, x, y, col);
    gfx->drawLine(px0, py + 1, x, y + 1, col);
    px0 = x;
    py = y;
  }
}

void drawFace() {
  page = PG_FACE;
  netPause = false;
  faceDirty = false;
  gfx->fillScreen(COL_BG);
  paintClock();
  paintWeather();
  chip(396, 18, 72, 28, "MENU", true);
  paintGraph();
  paintFear();
}

void drawMenu() {
  page = PG_MENU;
  gfx->fillScreen(COL_BG);
  chip(8, 14, 84, 22, "< BACK", false);
  chip(396, 14, 72, 22, "HOME", false);
  gfx->setTextColor(COL_HOT, COL_BG);
  gfx->setTextSize(2);
  centre("MENU", PW / 2, 16);
  chip(16, 56, 216, 48, "WIFI", false);
  chip(248, 56, 216, 48, "DIM", false);
  chip(16, 116, 216, 48, "LIGHT", false);
  chip(248, 116, 216, 48, "COINS", true);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_WHT, COL_BG);
  centre(blWord(), PW / 2, 184);
  chip(16, 176, 80, 28, "F", useC == 0);
  chip(384, 176, 80, 28, "C", useC == 1);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_MID, COL_BG);
  centre("DIM darker    LIGHT brighter", PW / 2, 214);
  chip(140, 230, 200, 28, "FACTORY RESET", false);
}

void drawCoins() {
  page = PG_COINS;
  gfx->fillScreen(COL_BG);
  chip(8, 14, 84, 22, "< BACK", false);
  chip(396, 14, 72, 22, "HOME", false);
  gfx->setTextColor(COL_HOT, COL_BG);
  gfx->setTextSize(2);
  centre("COINS", PW / 2, 16);
  for (int i = 0; i < NHOLD; i++) chip(8 + i * 118, 44, 112, 24, HOLD_NAME[i], i == holdIx);
  for (int i = 0; i < NRANGE; i++) chip(8 + i * 118, 74, 112, 24, RANGE_NAME[i], i == rangeIx);
  chip(8, 104, 150, 24, "LINE", lookIx == 0);
  chip(166, 104, 150, 24, "FILL", lookIx == 1);
  chip(324, 104, 150, 24, "CANDLE", lookIx == 2);
  for (int i = 0; i < NCOIN; i++) {
    int col = i % 4;
    int row = i / 4;
    chip(8 + col * 118, 136 + row * 22, 112, 20, COINS[i].name, coinOn(i));
  }
}

void drawWifiField(int focus, const char *raw, const char *empty, int y) {
  bool on = wifiFocus == focus;
  gfx->fillRoundRect(46, y, 428, 20, 3, on ? COL_HOT : COL_DIM);
  gfx->setTextColor(on ? COL_BG : COL_TXT, on ? COL_HOT : COL_DIM);
  gfx->setTextSize(1);
  gfx->setCursor(52, y + 6);
  gfx->print(raw[0] ? raw : empty);
}

void drawKey(int x, int y, int w, int h, const char *t) {
  gfx->fillRoundRect(x, y, w, h, 3, COL_DIM);
  gfx->setTextColor(COL_TXT, COL_DIM);
  gfx->setTextSize(1);
  centre(t, x + w / 2, y + h / 2 - 4);
}

void drawRow(const char *s, int y) {
  int n = (int)strlen(s);
  for (int i = 0; i < n; i++) {
    char t[2] = {s[i], 0};
    drawKey(i * KW + 1, y, KW - 2, 20, t);
  }
}

void drawWifi() {
  page = PG_WIFI;
  netPause = true;
  gfx->fillScreen(COL_BG);
  chip(5, 5, 84, 20, "< BACK", false);
  chip(300, 5, 72, 20, "HOME", false);
  gfx->setTextColor(COL_HOT, COL_BG);
  gfx->setTextSize(1);
  centre("JOIN WIFI", PW / 2, 9);
  chip(391, 5, 84, 20, "SCAN", wifiScanBusy);
  chip(4, 30, 32, 22, "<", false);
  chip(444, 30, 32, 22, ">", false);
  for (int i = 0; i < 2; i++) {
    int idx = wifiScanTop + i;
    if (idx >= nWifiScan) break;
    char shownName[18];
    strlcpy(shownName, wifiScan[idx], sizeof(shownName));
    chip(40 + i * 200, 30, 196, 22, shownName, !strcmp(wifiScan[idx], wifiSsid));
  }
  if (wifiMsg[0] && nWifiScan == 0) {
    gfx->setTextColor(COL_HOT, COL_BG);
    gfx->setTextSize(1);
    centre(wifiMsg, PW / 2, 36);
  }
  gfx->setTextColor(COL_MID, COL_BG);
  gfx->setTextSize(1);
  gfx->setCursor(4, 60);
  gfx->print("SSID");
  drawWifiField(0, wifiSsid, "tap net or type", 56);
  gfx->setTextColor(COL_MID, COL_BG);
  gfx->setCursor(4, 84);
  gfx->print("PASS");
  drawWifiField(1, wifiPass, "type password", 80);
  const char *r0 = "1234567890";
  const char *r1 = wifiSym ? "!@#$%^&*()" : (wifiShift ? "QWERTYUIOP" : "qwertyuiop");
  const char *r2 = wifiSym ? "-_=+[]{};'" : (wifiShift ? "ASDFGHJKL" : "asdfghjkl");
  const char *r3 = wifiSym ? ",.<>/?\\|~`" : (wifiShift ? "ZXCVBNM.@-" : "zxcvbnm.@-");
  drawRow(r0, 106);
  drawRow(r1, 128);
  drawRow(r2, 150);
  drawRow(r3, 172);
  drawKey(432, 150, 46, 20, "DEL");
  chip(4, 196, 72, 22, wifiShift ? "ABC" : "abc", wifiShift);
  chip(80, 196, 240, 22, "SPACE", false);
  chip(324, 196, 72, 22, wifiSym ? "ABC" : "!#", wifiSym);
  chip(4, 222, 154, 28, "SAVE", true);
  chip(162, 222, 154, 28, "RESET WIFI", false);
  chip(320, 222, 156, 28, "FACTORY", false);
}

void startWifiScan() {
  nWifiScan = 0;
  wifiScanTop = 0;
  wifiScanBusy = true;
  strlcpy(wifiMsg, "scanning", sizeof(wifiMsg));
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, false);
  WiFi.scanDelete();
  WiFi.scanNetworks(true, false);
}

void openWifi() {
  wifiFocus = wifiSsid[0] ? 1 : 0;
  wifiMsg[0] = 0;
  netPause = true;
  startWifiScan();
  drawWifi();
}

void wifiAppend(char c) {
  char *d = wifiFocus ? wifiPass : wifiSsid;
  int n = (int)strlen(d);
  if (n < 62) {
    d[n] = c;
    d[n + 1] = 0;
  }
}

void wifiDel() {
  char *d = wifiFocus ? wifiPass : wifiSsid;
  int n = (int)strlen(d);
  if (n) d[n - 1] = 0;
}

bool hitRow(int x, int y, const char *s, int y0) {
  if (y < y0 || y >= y0 + 20) return false;
  int i = x / KW;
  int n = (int)strlen(s);
  if (i < 0 || i >= n) return false;
  wifiAppend(s[i]);
  if (wifiShift && s[i] >= 'A' && s[i] <= 'Z') wifiShift = false;
  return true;
}

void pollWifiScan() {
  if (!wifiScanBusy) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  wifiScanBusy = false;
  if (n < 0) n = 0;
  nWifiScan = 0;
  for (int i = 0; i < n && nWifiScan < 16; i++) {
    String s = WiFi.SSID(i);
    if (s.length() == 0) continue;
    strlcpy(wifiScan[nWifiScan], s.c_str(), 33);
    nWifiScan++;
  }
  WiFi.scanDelete();
  wifiScanTop = 0;
  if (nWifiScan) wifiMsg[0] = 0;
  else strlcpy(wifiMsg, "none found  type name", sizeof(wifiMsg));
  if (page == PG_WIFI) drawWifi();
}

void saveBl() {
  prefs.begin("cdesk", false);
  prefs.putInt("bl", blLevel);
  prefs.putInt("unit", useC);
  prefs.end();
}

void saveCoins() {
  prefs.begin("cdesk", false);
  prefs.putUInt("mask", coinMask);
  prefs.putInt("hold", holdIx);
  prefs.putInt("rng", rangeIx);
  prefs.putInt("look", lookIx);
  prefs.putInt("who", coinIx);
  prefs.end();
}

void loadPrefs() {
  prefs.begin("cdesk", true);
  strlcpy(wifiSsid, prefs.getString("ssid", "").c_str(), sizeof(wifiSsid));
  strlcpy(wifiPass, prefs.getString("pass", "").c_str(), sizeof(wifiPass));
  coinMask = prefs.getUInt("mask", 0x3);
  holdIx = prefs.getInt("hold", 1);
  rangeIx = prefs.getInt("rng", 2);
  lookIx = prefs.getInt("look", 0);
  coinIx = prefs.getInt("who", 0);
  blLevel = prefs.getInt("bl", 2);
  useC = prefs.getInt("unit", 0);
  prefs.end();
  if (coinMask == 0) coinMask = 0x3;
  if (holdIx < 0 || holdIx >= NHOLD) holdIx = 1;
  if (rangeIx < 0 || rangeIx >= NRANGE) rangeIx = 2;
  if (lookIx < 0 || lookIx > 2) lookIx = 0;
  if (coinIx < 0 || coinIx >= NCOIN) coinIx = 0;
  if (!coinOn(coinIx)) coinIx = nextOn(-1);
  if (blLevel < 0 || blLevel > 2) blLevel = 2;
  if (useC != 0 && useC != 1) useC = 0;
}

void saveWifi() {
  prefs.begin("cdesk", false);
  prefs.putString("ssid", wifiSsid);
  prefs.putString("pass", wifiPass);
  prefs.end();
}

void clearWifi() {
  wifiSsid[0] = 0;
  wifiPass[0] = 0;
  prefs.begin("cdesk", false);
  prefs.putString("ssid", "");
  prefs.putString("pass", "");
  prefs.end();
}

void factoryReset() {
  prefs.begin("cdesk", false);
  prefs.clear();
  prefs.end();
}

int readTouch(int *xs, int *ys, int maxN) {
  if (maxN < 1 || !ts.touched()) return 0;
  TS_Point a = ts.getPoint();
  delay(4);
  if (!ts.touched()) return 0;
  TS_Point b = ts.getPoint();
  if (abs(a.x - b.x) > 20 || abs(a.y - b.y) > 20) return 0;
  int px = map(((int)a.x + (int)b.x) / 2, 3800, 170, 0, PW - 1);
  int py = map(((int)a.y + (int)b.y) / 2, 250, 3800, 0, PH - 1);
  px = PW - 1 - px;
  py = PH - 1 - py;
  xs[0] = constrain(px, 0, PW - 1);
  ys[0] = constrain(py, 0, PH - 1);
  return 1;
}

void goHome() {
  if (page == PG_COINS) saveCoins();
  pullNow = true;
  drawFace();
}

void onTap(int x, int y) {
  if (page == PG_FACE) {
    if (hit(x, y, 396, 18, 468, 46)) drawMenu();
    return;
  }
  if (page == PG_MENU) {
    if (hit(x, y, 8, 14, 92, 36) || hit(x, y, 396, 14, 468, 36)) {
      goHome();
      return;
    }
    if (hit(x, y, 16, 56, 232, 104)) {
      openWifi();
      return;
    }
    if (hit(x, y, 248, 56, 464, 104)) {
      if (blLevel > 0) blLevel--;
      applyBl();
      saveBl();
      drawMenu();
      return;
    }
    if (hit(x, y, 16, 116, 232, 164)) {
      if (blLevel < 2) blLevel++;
      applyBl();
      saveBl();
      drawMenu();
      return;
    }
    if (hit(x, y, 248, 116, 464, 164)) {
      drawCoins();
      return;
    }
    if (hit(x, y, 16, 176, 96, 204) && useC != 0) {
      if (wxOk) wxC = wxC * 9.f / 5.f + 32.f;
      useC = 0;
      saveBl();
      drawMenu();
      return;
    }
    if (hit(x, y, 384, 176, 464, 204) && useC != 1) {
      if (wxOk) wxC = (wxC - 32.f) * 5.f / 9.f;
      useC = 1;
      saveBl();
      drawMenu();
      return;
    }
    if (hit(x, y, 140, 230, 340, 258)) {
      factoryReset();
      delay(200);
      ESP.restart();
      return;
    }
    return;
  }
  if (page == PG_COINS) {
    if (hit(x, y, 396, 14, 468, 36)) {
      goHome();
      return;
    }
    if (hit(x, y, 8, 14, 92, 36)) {
      saveCoins();
      pullNow = true;
      drawMenu();
      return;
    }
    if (y >= 44 && y <= 68) {
      int i = (x - 8) / 118;
      if (i >= 0 && i < NHOLD) {
        holdIx = i;
        saveCoins();
        drawCoins();
      }
      return;
    }
    if (y >= 74 && y <= 98) {
      int i = (x - 8) / 118;
      if (i >= 0 && i < NRANGE) {
        rangeIx = i;
        saveCoins();
        pullNow = true;
        drawCoins();
      }
      return;
    }
    if (y >= 104 && y <= 128) {
      int i = (x - 8) / 158;
      if (i >= 0 && i < 3 && i != lookIx) {
        lookIx = i;
        saveCoins();
        drawCoins();
      }
      return;
    }
    if (y >= 136 && y < 224) {
      int row = (y - 136) / 22;
      int col = (x - 8) / 118;
      int i = row * 4 + col;
      if (i >= 0 && i < NCOIN) {
        uint32_t bit = 1UL << i;
        if (coinMask & bit) {
          if ((coinMask & ~bit) != 0) coinMask &= ~bit;
        } else
          coinMask |= bit;
        if (!coinOn(coinIx)) coinIx = nextOn(-1);
        saveCoins();
        pullNow = true;
        drawCoins();
      }
    }
    return;
  }
  if (page != PG_WIFI) return;
  if (hit(x, y, 300, 5, 372, 25)) {
    goHome();
    return;
  }
  if (hit(x, y, 5, 5, 89, 25)) {
    drawMenu();
    return;
  }
  if (hit(x, y, 391, 5, 475, 25)) {
    startWifiScan();
    drawWifi();
    return;
  }
  if (hit(x, y, 4, 30, 36, 52) && wifiScanTop > 0) {
    wifiScanTop -= 2;
    if (wifiScanTop < 0) wifiScanTop = 0;
    drawWifi();
    return;
  }
  if (hit(x, y, 444, 30, 476, 52) && wifiScanTop + 2 < nWifiScan) {
    wifiScanTop += 2;
    drawWifi();
    return;
  }
  for (int i = 0; i < 2; i++) {
    int idx = wifiScanTop + i;
    if (idx >= nWifiScan) break;
    if (hit(x, y, 40 + i * 200, 30, 235 + i * 200, 52)) {
      strlcpy(wifiSsid, wifiScan[idx], sizeof(wifiSsid));
      wifiFocus = 1;
      drawWifi();
      return;
    }
  }
  if (hit(x, y, 46, 56, 474, 76)) {
    wifiFocus = 0;
    drawWifi();
    return;
  }
  if (hit(x, y, 46, 80, 474, 100)) {
    wifiFocus = 1;
    drawWifi();
    return;
  }
  if (hit(x, y, 4, 222, 158, 250)) {
    if (!wifiSsid[0]) {
      strlcpy(wifiMsg, "need wifi name", sizeof(wifiMsg));
      drawWifi();
      return;
    }
    saveWifi();
    gfx->fillScreen(COL_BG);
    gfx->setTextColor(COL_HOT, COL_BG);
    gfx->setTextSize(1);
    centre("saved", PW / 2, 120);
    delay(400);
    ESP.restart();
    return;
  }
  if (hit(x, y, 162, 222, 316, 250)) {
    clearWifi();
    strlcpy(wifiMsg, "wifi cleared", sizeof(wifiMsg));
    drawWifi();
    return;
  }
  if (hit(x, y, 320, 222, 476, 250)) {
    factoryReset();
    delay(200);
    ESP.restart();
    return;
  }
  if (hit(x, y, 4, 196, 76, 218)) {
    wifiShift = !wifiShift;
    wifiSym = false;
    drawWifi();
    return;
  }
  if (hit(x, y, 80, 196, 320, 218)) {
    wifiAppend(' ');
    drawWifi();
    return;
  }
  if (hit(x, y, 324, 196, 396, 218)) {
    wifiSym = !wifiSym;
    drawWifi();
    return;
  }
  if (hit(x, y, 432, 150, 478, 170)) {
    wifiDel();
    drawWifi();
    return;
  }
  const char *r0 = "1234567890";
  const char *r1 = wifiSym ? "!@#$%^&*()" : (wifiShift ? "QWERTYUIOP" : "qwertyuiop");
  const char *r2 = wifiSym ? "-_=+[]{};'" : (wifiShift ? "ASDFGHJKL" : "asdfghjkl");
  const char *r3 = wifiSym ? ",.<>/?\\|~`" : (wifiShift ? "ZXCVBNM.@-" : "zxcvbnm.@-");
  if (hitRow(x, y, r0, 106) || hitRow(x, y, r1, 128) || hitRow(x, y, r2, 150) || hitRow(x, y, r3, 172))
    drawWifi();
}

void connectWifi() {
  if (!wifiSsid[0]) {
    openWifi();
    return;
  }
  gfx->fillScreen(COL_BG);
  gfx->setTextColor(COL_HOT, COL_BG);
  gfx->setTextSize(1);
  centre("linking", PW / 2, 120);
  centre(wifiSsid, PW / 2, 142);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(50);
  if (WiFi.status() == WL_CONNECTED)
    configTzTime("PST8PDT,M3.2.0,M11.1.0", "pool.ntp.org", "time.nist.gov");
  drawFace();
}

void setup() {
  cols();
  setenv("TZ", "PST8PDT,M3.2.0,M11.1.0", 1);
  tzset();
  Serial.begin(115200);
  applyBl();
  SPI.begin(TOUCH_SCK, TOUCH_MISO, TOUCH_MOSI, TOUCH_CS);
  ts.begin();
  ts.setRotation(0);
  rgbBus = new Arduino_ESP32RGBPanel(
      PIN_DE, PIN_VSYNC, PIN_HSYNC, PIN_PCLK,
      45, 48, 47, 21, 14,
      5, 6, 7, 15, 16, 4,
      8, 3, 46, 9, 1,
      0, 8, 4, 43,
      0, 8, 4, 12,
      1, 9000000, false, 0, 0, 272 * 20);
  panel = new Arduino_RGB_Display(PW, PH, rgbBus, 2, true);
  if (!panel->begin()) {
    Serial.println("gfx begin failed");
    return;
  }
  gfx = panel;
  gfx->setTextWrap(false);
  gfx->fillScreen(COL_BG);
  applyBl();
  loadPrefs();
  applyBl();
  lastTouch = millis();
  xTaskCreatePinnedToCore(netTask, "coins", 40960, nullptr, 1, nullptr, 0);
  connectWifi();
  applyBl();
}

void loop() {
  if (!gfx) return;
  pollWifiScan();
  int xs[1], ys[1];
  int nTouch = readTouch(xs, ys, 1);
  if (nTouch == 1) {
    if (!fingerDown && millis() - lastTouch > 180UL) {
      fingerDown = true;
      lastTouch = millis();
      onTap(xs[0], ys[0]);
    }
  } else
    fingerDown = false;
  if (page == PG_FACE && faceDirty) drawFace();
  if (page == PG_FACE) {
    static int shownMin = -1;
    time_t now = time(nullptr);
    struct tm ti;
    if (now > 1700000000L && localtime_r(&now, &ti) && ti.tm_min != shownMin) {
      shownMin = ti.tm_min;
      paintClock();
    }
  }
  delay(8);
}
